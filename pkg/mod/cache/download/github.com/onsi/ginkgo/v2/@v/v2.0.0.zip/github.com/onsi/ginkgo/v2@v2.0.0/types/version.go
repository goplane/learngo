package types

const VERSION = "2.0.0"
